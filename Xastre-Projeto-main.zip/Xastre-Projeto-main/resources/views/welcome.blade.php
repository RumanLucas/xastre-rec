@extends('layout.main')

@section('title','REX')
    
@section('content')

<h1>Bem Vindo</h1>


@endsection 
